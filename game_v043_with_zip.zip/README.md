# Quest6Game1

Made for [QuestJS](https://github.com/ThePix/QuestJS)
